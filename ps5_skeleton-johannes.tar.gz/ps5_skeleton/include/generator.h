#ifndef GENERATOR_H
#define GENERATOR_H
void generate_program ( void );
#endif
